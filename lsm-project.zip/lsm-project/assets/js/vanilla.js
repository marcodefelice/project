/*!
 * Vanilla.js JavaScript Library v1.0.0
 * http://colynb.com/vanilla.js/
 *
 * Copyright 2011, 2012, 2013 Colyn Brown
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2013-08-20T13:48Z
 */
 
